package com.seunome.laytandroid;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class EditLayoutActivity extends AppCompatActivity {

    private String layoutName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_layout);

        // Recebe o layout escolhido da MainActivity
        layoutName = getIntent().getStringExtra("LAYOUT_NAME");

        // Configura o layout editado com base no nome recebido
        if ("LinearLayout".equals(layoutName)) {
            // Aqui você pode configurar o layout para edição
        } else if ("RelativeLayout".equals(layoutName)) {
            // Configura para o RelativeLayout
        } else if ("ConstraintLayout".equals(layoutName)) {
            // Configura para o ConstraintLayout
        }
    }

    // Método que será chamado ao clicar no botão "Visualizar"
    public void onVisualizeClicked(View view) {
        // Iniciar a visualização do layout editado
        Intent intent = new Intent(EditLayoutActivity.this, LayoutPreviewActivity.class);
        intent.putExtra("LAYOUT_NAME", layoutName);
        startActivity(intent);
    }

    // Método para voltar à tela inicial
    public void onBackClicked(View view) {
        finish();
    }
}