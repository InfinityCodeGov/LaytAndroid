package com.seunome.laytandroid;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    // Método que será chamado quando o usuário selecionar um layout
    public void onLayoutSelected(View view) {
        String layoutName = "";

        // Identificar qual layout foi selecionado
        switch (view.getId()) {
            case R.id.linearLayoutButton:
                layoutName = "LinearLayout";
                break;
            case R.id.relativeLayoutButton:
                layoutName = "RelativeLayout";
                break;
            case R.id.constraintLayoutButton:
                layoutName = "ConstraintLayout";
                break;
        }

        // Enviar para a EditLayoutActivity com o layout escolhido
        Intent intent = new Intent(MainActivity.this, EditLayoutActivity.class);
        intent.putExtra("LAYOUT_NAME", layoutName);
        startActivity(intent);
    }
}